/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modelo;

/**
 *
 * @author Jordy
 */
public class InterfaceOpinion extends javax.swing.JFrame {

    private String calificacionSeleccionada = "";

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(InterfaceOpinion.class.getName());

    public InterfaceOpinion() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        btnExcelente = new javax.swing.JButton();
        btnBueno = new javax.swing.JButton();
        btnRegular = new javax.swing.JButton();
        btnMalo = new javax.swing.JButton();
        btnMuyMalo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtComentario = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        btnEnviar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(101, 36, 42));
        jLabel2.setText("¿COMÓ FUE TU EXPERIENCIA EL DIA DE HOY?");
        jLabel2.setOpaque(true);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, -1, -1));

        btnExcelente.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnExcelente.setForeground(new java.awt.Color(101, 36, 42));
        btnExcelente.setText("EXCELENTE ");
        btnExcelente.addActionListener(this::btnExcelenteActionPerformed);
        getContentPane().add(btnExcelente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, -1));

        btnBueno.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnBueno.setForeground(new java.awt.Color(101, 36, 42));
        btnBueno.setText("BUENO");
        btnBueno.addActionListener(this::btnBuenoActionPerformed);
        getContentPane().add(btnBueno, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 132, -1));

        btnRegular.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnRegular.setForeground(new java.awt.Color(101, 36, 42));
        btnRegular.setText("REGULAR");
        btnRegular.addActionListener(this::btnRegularActionPerformed);
        getContentPane().add(btnRegular, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 130, -1));

        btnMalo.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnMalo.setForeground(new java.awt.Color(101, 36, 42));
        btnMalo.setText("MALO");
        btnMalo.addActionListener(this::btnMaloActionPerformed);
        getContentPane().add(btnMalo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 132, -1));

        btnMuyMalo.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnMuyMalo.setForeground(new java.awt.Color(101, 36, 42));
        btnMuyMalo.setText("MUY MALO");
        btnMuyMalo.addActionListener(this::btnMuyMaloActionPerformed);
        getContentPane().add(btnMuyMalo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 132, -1));

        jScrollPane1.setForeground(new java.awt.Color(101, 36, 42));

        txtComentario.setColumns(20);
        txtComentario.setRows(5);
        jScrollPane1.setViewportView(txtComentario);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 360, 190));

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(101, 36, 42));
        jLabel3.setText("DÉJANOS TU COMENTARIO:");
        jLabel3.setOpaque(true);
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, 380, -1));

        btnEnviar.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btnEnviar.setForeground(new java.awt.Color(101, 36, 42));
        btnEnviar.setText("ENVIAR OPINIÓN");
        btnEnviar.addActionListener(this::btnEnviarActionPerformed);
        getContentPane().add(btnEnviar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 350, 350, 40));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modelo/imagenes/miku.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 110, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExcelenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcelenteActionPerformed
        calificacionSeleccionada = "EXCELENTE";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: EXCELENTE");
    }//GEN-LAST:event_btnExcelenteActionPerformed

    private void btnRegularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegularActionPerformed
        calificacionSeleccionada = "REGULAR";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: REGULAR");
    }//GEN-LAST:event_btnRegularActionPerformed

    private void btnMaloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaloActionPerformed
        calificacionSeleccionada = "MALO";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: MALO");
    }//GEN-LAST:event_btnMaloActionPerformed

    private void btnMuyMaloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMuyMaloActionPerformed
        calificacionSeleccionada = "MUY MALO";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: MUY MALO");
    }//GEN-LAST:event_btnMuyMaloActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
        if (calificacionSeleccionada.equals("")) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Por favor, selecciona una calificación antes de enviar tu opinión.",
                    "Atención",
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        String comentario = txtComentario.getText().trim();

        String mensajeExito = "¡Gracias por tu opinión!\n"
                + "Calificación: " + calificacionSeleccionada + "\n"
                + "Comentario: " + (comentario.isEmpty() ? "Ninguno" : comentario);

        javax.swing.JOptionPane.showMessageDialog( this, 
            "chao chao >⩊<", 
            "Vuelva prontooo", 
                javax.swing.JOptionPane.INFORMATION_MESSAGE);

        calificacionSeleccionada = "";
        txtComentario.setText("");
         
        System.exit(0);
    }//GEN-LAST:event_btnEnviarActionPerformed

    private void btnBuenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuenoActionPerformed

        calificacionSeleccionada = "Bueno";
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccionaste: BUENO");

    }//GEN-LAST:event_btnBuenoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new InterfaceOpinion().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBueno;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnExcelente;
    private javax.swing.JButton btnMalo;
    private javax.swing.JButton btnMuyMalo;
    private javax.swing.JButton btnRegular;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtComentario;
    // End of variables declaration//GEN-END:variables
}
