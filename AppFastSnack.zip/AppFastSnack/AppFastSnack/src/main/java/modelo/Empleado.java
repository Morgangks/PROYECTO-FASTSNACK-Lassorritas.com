/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author fl1pc12
 */
public class Empleado extends Persona {

    public Empleado(String nombre, String telefono) {
        super(nombre, telefono);
    }

    @Override
    void accederCliente() {
        System.out.println("Hola soy nueva y me llamo lala");
    }
    
}
