/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package modelo;

public class AppFastSnack {

    public static void main(String[] args) {

        Interfaz_Bienvenida ventana = new Interfaz_Bienvenida();

        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);

    }

}
