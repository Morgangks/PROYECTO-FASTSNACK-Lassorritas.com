/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author fl1pc12
 */
public class Pedido {
    private Clientes clientes;
    private ArrayList<Producto> productos;
    private String estado;
    private LocalDateTime fecha;

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    //Constructor
    public Pedido(Clientes clientes, ArrayList<Producto> productos, String estado) {
        this.clientes = clientes;
        this.productos = new ArrayList<>();
        this.estado = estado;
        this.fecha = LocalDateTime.now();
    }
    //metodos
    public void agregarProducto(Producto p){
        productos.add(p);
    }
   public double calcularTotal(){
        double total = 0;
        for(Producto p : productos){
        total+= p.getPrecio();
       }
        return total;
   }
    public void mostrarPedido(){
        System.out.println("Cliente:" + clientes.getNombre());
        System.out.println("Fecha:" + fecha);
        System.out.println("Estado:" + estado);
        
        System.out.println("Productos:");
        for(Producto p : productos){
            System.out.println("-" + p.getNombre()+ "$" + p.getPrecio());
        }
        System.out.println("Total:$" + calcularTotal());
  }
}
