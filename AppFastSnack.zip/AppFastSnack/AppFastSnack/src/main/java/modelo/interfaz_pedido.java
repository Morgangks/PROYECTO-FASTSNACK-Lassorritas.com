package modelo;

import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Config.Conexion;
import javax.swing.JDialog;

public class interfaz_pedido extends javax.swing.JFrame {

    private void mostrarMensajeAutoCerrable(String mensaje, String titulo, int milisegundos) {
        JOptionPane optionPane = new JOptionPane(mensaje, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(this, titulo);
        javax.swing.Timer timer = new javax.swing.Timer(milisegundos, e -> dialog.dispose());
        timer.setRepeats(false);
        timer.start();
        dialog.setVisible(true);
    }

    private void buscarPedido() {
        try {
            String texto = lblNumerodepedido.getText().trim();

            if (texto.isEmpty()) {
                mostrarMensajeAutoCerrable("Ingrese un número de pedido", "Atención", 1500);
                return;
            }

            int idPedido = Integer.parseInt(texto);
            Connection con = Conexion.getInstance().getConnection();

            String sqlPedido = "SELECT pe.id_pedido, per.nombre, ep.nombre_estado " +
                               "FROM Pedido pe " +
                               "INNER JOIN Cliente c ON pe.id_cliente = c.id_cliente " +
                               "INNER JOIN Persona per ON c.id_cliente = per.id_persona " +
                               "INNER JOIN EstadoPedido ep ON pe.id_estado = ep.id_estado " +
                               "WHERE pe.id_pedido = ?";

            PreparedStatement psPedido = con.prepareStatement(sqlPedido);
            psPedido.setInt(1, idPedido);
            ResultSet rsPedido = psPedido.executeQuery();

            if (rsPedido.next()) {
                txtIngresoNombre.setText(rsPedido.getString("nombre"));
                String estado = rsPedido.getString("nombre_estado");
                
                // Selecciona el estado en la lista rosa (lstEstados) en pantalla
                lstEstados.setSelectedValue(estado, true);

                String sqlProductos = "SELECT pr.nombre, pp.cantidad, pr.precio " +
                                      "FROM PedidoProducto pp " +
                                      "INNER JOIN Producto pr ON pp.id_producto = pr.id_producto " +
                                      "WHERE pp.id_pedido = ?";

                PreparedStatement psProd = con.prepareStatement(sqlProductos);
                psProd.setInt(1, idPedido);
                ResultSet rsProd = psProd.executeQuery();

                DefaultTableModel modelo = (DefaultTableModel) tblProductos.getModel();
                modelo.setRowCount(0);

                while (rsProd.next()) {
                    String producto = rsProd.getString("nombre");
                    double precio = rsProd.getDouble("precio");
                    int cantidad = rsProd.getInt("cantidad");
                    double totalItem = cantidad * precio;

                    // Coincide con las columnas definidas: Producto, Precio, Total
                    modelo.addRow(new Object[]{producto, precio, totalItem});
                }
                
                rsProd.close();
                psProd.close();

            } else {
                mostrarMensajeAutoCerrable("Pedido no encontrado", "Sin resultados", 1500);
            }

            rsPedido.close();
            psPedido.close();

        } catch (NumberFormatException e) {
            mostrarMensajeAutoCerrable("El ID de pedido debe ser un número entero.", "Error", 1500);
        } catch (Exception e) {
            mostrarMensajeAutoCerrable("Error al buscar: " + e.getMessage(), "Error", 2000);
        }
    }
        
    public static class Datos {
        public static ArrayList<Pedido> listaPedidos = new ArrayList<>();
    }

    public interfaz_pedido() {
        initComponents();
        lblNumerodepedido.setEditable(true);

        comboEstado1.removeAllItems();
        comboEstado1.addItem("Pendiente");
        comboEstado1.addItem("Preparando");
        comboEstado1.addItem("Enviado");
        comboEstado1.addItem("Entregado");
    }

    public interfaz_pedido(String nombreCliente, int ticketGenerado, List<Object[]> productosComprados) {
        initComponents();
        lblNumerodepedido.setEditable(false);

        lblNombre.setText(nombreCliente);
        lblNumerodepedido.setText(String.valueOf(ticketGenerado));

        DefaultTableModel modelo = (DefaultTableModel) tblProductos.getModel();
        modelo.setRowCount(0);

        for (Object[] producto : productosComprados) {
            modelo.addRow(producto);
        }

        comboEstado1.removeAllItems();
        comboEstado1.addItem("Pendiente");
        comboEstado1.addItem("Preparando");
        comboEstado1.addItem("Enviado");
        comboEstado1.addItem("Entregado");
    }

    public boolean isCellEditable(int row, int column) {
        return false;
    }

    public void recibirDatosDelPedido(String nombreCliente, String numeroTicket) {
        lblNombre.setText(nombreCliente);
        lblNumerodepedido.setText(numeroTicket);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        comboEstado1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        btnrRegresa = new javax.swing.JButton();
        lblNumerodepedido = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        btnFinal = new javax.swing.JButton();
        lblNombre = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstEstados = new javax.swing.JList<>();
        btnActualizar = new javax.swing.JButton();
        txtIngresoNombre = new javax.swing.JTextField();
        bntBuscar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel5.setForeground(new java.awt.Color(255, 102, 153));

        jLabel10.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 153));
        jLabel10.setText("Estado del pedido");

        comboEstado1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        comboEstado1.setForeground(new java.awt.Color(255, 0, 153));
        comboEstado1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(0, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox2, 0, 105, Short.MAX_VALUE))
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(comboEstado1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(comboEstado1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setText("jLabel1");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(237, 170, 179));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 35, 44));
        jLabel4.setText("N°");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, -1, 28));

        btnrRegresa.setBackground(new java.awt.Color(248, 229, 212));
        btnrRegresa.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        btnrRegresa.setForeground(new java.awt.Color(102, 35, 44));
        btnrRegresa.setText("regresar al menu");
        btnrRegresa.setToolTipText("");
        btnrRegresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrRegresaActionPerformed(evt);
            }
        });
        jPanel3.add(btnrRegresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 20, -1, -1));

        lblNumerodepedido.setBackground(new java.awt.Color(248, 229, 212));
        lblNumerodepedido.setForeground(new java.awt.Color(102, 35, 44));
        lblNumerodepedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblNumerodepedidoActionPerformed(evt);
            }
        });
        jPanel3.add(lblNumerodepedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 230, 30));

        jLabel5.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 35, 44));
        jLabel5.setText("cliente");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, 90, -1));

        jScrollPane4.setBackground(new java.awt.Color(248, 229, 212));
        jScrollPane4.setForeground(new java.awt.Color(102, 35, 44));

        tblProductos.setBackground(new java.awt.Color(248, 229, 212));
        tblProductos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tblProductos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        tblProductos.setForeground(new java.awt.Color(101, 36, 42));
        tblProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Producto", "Precio", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblProductos.setToolTipText("");
        tblProductos.setColumnSelectionAllowed(true);
        tblProductos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane4.setViewportView(tblProductos);
        tblProductos.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        if (tblProductos.getColumnModel().getColumnCount() > 0) {
            tblProductos.getColumnModel().getColumn(0).setHeaderValue("Producto");
            tblProductos.getColumnModel().getColumn(1).setHeaderValue("Precio");
            tblProductos.getColumnModel().getColumn(2).setHeaderValue("Total");
        }

        jPanel3.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(41, 155, 430, 169));

        btnFinal.setBackground(new java.awt.Color(248, 229, 212));
        btnFinal.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        btnFinal.setForeground(new java.awt.Color(102, 35, 44));
        btnFinal.setText("Finalizar ");
        btnFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalActionPerformed(evt);
            }
        });
        jPanel3.add(btnFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(41, 342, 430, 40));
        jPanel3.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(653, 143, 376, -1));

        jLabel6.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 35, 44));
        jLabel6.setText("Estado del pedido");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 120, 190, -1));

        jScrollPane3.setForeground(new java.awt.Color(102, 35, 44));

        lstEstados.setBackground(new java.awt.Color(248, 229, 212));
        lstEstados.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lstEstados.setForeground(new java.awt.Color(101, 36, 42));
        lstEstados.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Pendiente", "Revision","Enviado","Entregado"};
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(lstEstados);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(516, 155, 202, 169));

        btnActualizar.setBackground(new java.awt.Color(248, 229, 212));
        btnActualizar.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(102, 35, 44));
        btnActualizar.setText("actualizar estado");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        jPanel3.add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(516, 344, 202, 40));

        txtIngresoNombre.setBackground(new java.awt.Color(248, 229, 212));
        txtIngresoNombre.setForeground(new java.awt.Color(102, 35, 44));
        txtIngresoNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIngresoNombreActionPerformed(evt);
            }
        });
        jPanel3.add(txtIngresoNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 340, 30));

        bntBuscar.setBackground(new java.awt.Color(248, 229, 212));
        bntBuscar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        bntBuscar.setForeground(new java.awt.Color(102, 35, 44));
        bntBuscar.setText("Buscar");
        bntBuscar.setBorder(null);
        bntBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntBuscarActionPerformed(evt);
            }
        });
        jPanel3.add(bntBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(305, 50, 150, 30));

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 735, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
  try {
            String texto = lblNumerodepedido.getText().trim();
            if (texto.isEmpty()) {
                mostrarMensajeAutoCerrable("Primero busque un pedido.", "Atención", 1500);
                return;
            }

            int idPedido = Integer.parseInt(texto);
            Connection con = Conexion.getInstance().getConnection();

            // 1. Obtener el id_estado actual desde la base de datos
            String sqlBuscar = "SELECT id_estado FROM Pedido WHERE id_pedido=?";
            PreparedStatement psBuscar = con.prepareStatement(sqlBuscar);
            psBuscar.setInt(1, idPedido);
            ResultSet rs = psBuscar.executeQuery();

            int idEstadoActual = 1;
            if (rs.next()) {
                idEstadoActual = rs.getInt("id_estado");
            }
            rs.close();
            psBuscar.close();

            // 2. Determinar la SECUENCIA correcta de avance (+1 estado)
            int nuevoEstado;
            String nombreEstado = "";

            switch (idEstadoActual) {
                case 1: 
                    nuevoEstado = 2; 
                    nombreEstado = "Revision"; 
                    break;
                case 2: 
                    nuevoEstado = 3; 
                    nombreEstado = "Enviado"; 
                    break;
                case 3: 
                    nuevoEstado = 4; 
                    nombreEstado = "Entregado"; 
                    break;
                default: 
                    mostrarMensajeAutoCerrable("El pedido ya está en el estado final (Entregado).", "Estado Final", 1500);
                    return;
            }

            // 3. Guardar el avance en la BD
            String sqlUpdate = "UPDATE Pedido SET id_estado=? WHERE id_pedido=?";
            PreparedStatement psUpdate = con.prepareStatement(sqlUpdate);
            psUpdate.setInt(1, nuevoEstado);
            psUpdate.setInt(2, idPedido);
            psUpdate.executeUpdate();
            psUpdate.close();

            // 4. Seleccionar visualmente el nuevo estado en la lista JList (lstEstados)
            lstEstados.setSelectedValue(nombreEstado, true);

            // 5. Mostrar ventana que se cierra sola en 1.5 segundos
            mostrarMensajeAutoCerrable("Estado actualizado a: " + nombreEstado, "Éxito", 1500);

        } catch (Exception e) {
            mostrarMensajeAutoCerrable("Error: " + e.getMessage(), "Error", 2000);
        }
    
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalActionPerformed
Object[] opciones = {"Cerrar app", "Dejar una opinión"};

    int seleccion = JOptionPane.showOptionDialog(
        this,
        "¡Pedido finalizado correctamente!\n¿Qué deseas hacer a continuación?",
        "Finalizar Pedido",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        opciones,
        opciones[1] // Opción por defecto
    );

    if (seleccion == JOptionPane.NO_OPTION) { 
        Interfaz_Bienvenida menu = new Interfaz_Bienvenida();
        menu.setVisible(true);
        this.dispose();
    } else if (seleccion == JOptionPane.YES_OPTION) {
        this.dispose();
    }
    }//GEN-LAST:event_btnFinalActionPerformed

    private void btnrRegresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrRegresaActionPerformed
        Interfaz_Bienvenida menu = new Interfaz_Bienvenida(); //AGREGAR PRINCIPL
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnrRegresaActionPerformed

    private void lblNumerodepedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblNumerodepedidoActionPerformed
       
    }//GEN-LAST:event_lblNumerodepedidoActionPerformed

    private void txtIngresoNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIngresoNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIngresoNombreActionPerformed

    private void bntBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntBuscarActionPerformed
       buscarPedido();
    }//GEN-LAST:event_bntBuscarActionPerformed
    private static class MenuPrincipal {

        private void setVisible(boolean b) {
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
          try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(interfaz_pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new interfaz_pedido().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bntBuscar;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnFinal;
    private javax.swing.JButton btnrRegresa;
    private javax.swing.JComboBox<String> comboEstado1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTextField lblNumerodepedido;
    private javax.swing.JList<String> lstEstados;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtIngresoNombre;
    // End of variables declaration//GEN-END:variables

}
