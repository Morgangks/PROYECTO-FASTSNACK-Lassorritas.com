/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modelo;

/**
 *
 * @author fl1pc12
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import Config.Conexion;


public class Interfaz_Bienvenida extends javax.swing.JFrame {

    private int idClienteGuardado = 0;

    public Interfaz_Bienvenida() {
        initComponents();
        this.getContentPane().setBackground(java.awt.Color.decode("#EDAAB3"));
        
}
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnRealizarPedido = new javax.swing.JButton();
        txtNombreCliente = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        btnGuardarCliente = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txtDireccion = new javax.swing.JTextField();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(96, 0, 0));
        jLabel1.setText("¡BIENVENIDO!");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 280, 205, 30));

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(96, 0, 0));
        jLabel2.setText("Dirección:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 430, 120, -1));

        jLabel4.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(96, 0, 0));
        jLabel4.setText("# Teléfonico:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, 140, -1));

        btnRealizarPedido.setBackground(new java.awt.Color(102, 35, 44));
        btnRealizarPedido.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        btnRealizarPedido.setForeground(new java.awt.Color(255, 255, 255));
        btnRealizarPedido.setText("<html><center>Realizar<br>Pedido</center></html>");
        btnRealizarPedido.setBorder(null);
        btnRealizarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRealizarPedidoActionPerformed(evt);
            }
        });
        getContentPane().add(btnRealizarPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 140, 70));

        txtNombreCliente.setBackground(new java.awt.Color(252, 228, 221));
        txtNombreCliente.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        txtNombreCliente.setForeground(new java.awt.Color(68, 39, 31));
        txtNombreCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreClienteActionPerformed(evt);
            }
        });
        getContentPane().add(txtNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 330, 380, -1));

        jTextField2.setBackground(new java.awt.Color(252, 228, 221));
        jTextField2.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(68, 39, 31));
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField2KeyTyped(evt);
            }
        });
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 380, 380, -1));

        btnGuardarCliente.setBackground(new java.awt.Color(102, 35, 44));
        btnGuardarCliente.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        btnGuardarCliente.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardarCliente.setText("Guardar Datos");
        btnGuardarCliente.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarClienteActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardarCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 480, 180, 40));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setForeground(new java.awt.Color(255, 0, 153));
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, -1, 500));

        jButton2.setBackground(new java.awt.Color(102, 35, 44));
        jButton2.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("<html><center>Ver Estado<br>Del Pedido</center></html>");
        jButton2.setActionCommand("<html><center>Ver Estado<br>Del Pedido</center></html>");
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 170, 140, 70));

        jButton1.setBackground(new java.awt.Color(102, 35, 44));
        jButton1.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("<html><center>Personalizar<br>pedido</center></html>");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 140, 70));

        jButton3.setBackground(new java.awt.Color(102, 35, 44));
        jButton3.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("<html><center>¡Danos tu<br>opinión!</center></html>");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 170, 140, 70));
        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        jPanel2.setBackground(new java.awt.Color(252, 228, 221));
        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 690, 110));

        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 35, 44));
        jLabel3.setText("Nombre:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 330, -1, -1));

        jLabel67.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(126, 44, 55));
        jLabel67.setText("Ctrl + Eats");
        getContentPane().add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modelo/imagenes/logo.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, -1, -1));

        jPanel1.setBackground(new java.awt.Color(102, 35, 44));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -20, 690, 80));

        txtDireccion.setBackground(new java.awt.Color(252, 228, 221));
        txtDireccion.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        txtDireccion.setForeground(new java.awt.Color(68, 39, 31));
        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });
        getContentPane().add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 430, 380, -1));

        btnSalir.setBackground(new java.awt.Color(102, 35, 44));
        btnSalir.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(255, 255, 255));
        btnSalir.setText("salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 640, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRealizarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRealizarPedidoActionPerformed
        if (idClienteGuardado == 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Primero debes guardar los datos del cliente."
            );
            return;
        }

        modelo.MenuComida menu
                = new modelo.MenuComida(idClienteGuardado);

        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRealizarPedidoActionPerformed

    private void txtNombreClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreClienteActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void btnGuardarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarClienteActionPerformed
       String nombre = txtNombreCliente.getText().trim();
String direccion = txtDireccion.getText().trim();
String telefono = jTextField2.getText().trim();

// 1. VALIDACIÓN DE CAMPOS VACÍOS
if (nombre.isEmpty() || direccion.isEmpty() || telefono.isEmpty()) {
    JOptionPane.showMessageDialog(this, 
        "Debe llenar todos los campos antes de guardar.", 
        "Campos incompletos", 
        JOptionPane.WARNING_MESSAGE);
    return;
}

// 2. VALIDAR NOMBRE (Mínimo 3 letras, solo letras y espacios, no solo números ni 1 sola letra)
if (!nombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{3,}$")) {
    JOptionPane.showMessageDialog(this, 
        "El nombre ingresado no es válido. Debe contener al menos 3 letras y no incluir números.", 
        "Nombre inválido", 
        JOptionPane.WARNING_MESSAGE);
    return;
}

// 3. VALIDAR TELÉFONO (Solo dígitos y una longitud razonable, por ejemplo entre 7 y 10 dígitos)
if (!telefono.matches("^\\d{7,10}$")) {
    JOptionPane.showMessageDialog(this, 
        "El número telefónico debe contener solo números (entre 7 y 10 dígitos).", 
        "Teléfono inválido", 
        JOptionPane.WARNING_MESSAGE);
    return;
}

// 4. VALIDAR DIRECCIÓN (Mínimo 5 caracteres para evitar valores como "243243" o caracteres sueltos)
if (direccion.length() < 5) {
    JOptionPane.showMessageDialog(this, 
        "La dirección es demasiado corta. Ingrese una dirección válida.", 
        "Dirección inválida", 
        JOptionPane.WARNING_MESSAGE);
    return;
}

// SI PASA TODAS LAS VALIDACIONES, EJECUTA LA BASE DE DATOS
try {
    Connection con = Conexion.getInstance().getConnection();

    String sqlPersona = "INSERT INTO Persona(nombre, telefono) VALUES (?, ?)";
    PreparedStatement psPersona = con.prepareStatement(sqlPersona, PreparedStatement.RETURN_GENERATED_KEYS);
    psPersona.setString(1, nombre);
    psPersona.setString(2, telefono);
    psPersona.executeUpdate();

    ResultSet rs = psPersona.getGeneratedKeys();
    int idPersona = 0;
    if (rs.next()) {
        idPersona = rs.getInt(1);
        idClienteGuardado = idPersona;
    }

    String sqlCliente = "INSERT INTO Cliente(id_cliente, direccion) VALUES (?, ?)";
    PreparedStatement psCliente = con.prepareStatement(sqlCliente);
    psCliente.setInt(1, idPersona);
    psCliente.setString(2, direccion);
    psCliente.executeUpdate();

    JOptionPane.showMessageDialog(this, "Cliente guardado correctamente");

    txtNombreCliente.setText("");
    txtDireccion.setText("");
    jTextField2.setText("");

    rs.close();
    psPersona.close();
    psCliente.close();

} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage());
}
    }//GEN-LAST:event_btnGuardarClienteActionPerformed

    private void jTextField2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2KeyTyped
        char c = evt.getKeyChar();

        if (!Character.isDigit(c)
                || jTextField2.getText().length() >= 10) {

            evt.consume();
        }
    }//GEN-LAST:event_jTextField2KeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       // TODO add your handling code here:
        interfaz_pedido ventanapedido = new interfaz_pedido();
        ventanapedido.setVisible(true); 
        this.dispose(); 
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        InterfaceOpinion ventanaOpinion = new InterfaceOpinion();
        ventanaOpinion.setVisible(true); 
        this.dispose(); 
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        InterfacePedidoPersonalizado ventanaPedido = new InterfacePedidoPersonalizado();
        ventanaPedido.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
        
    }//GEN-LAST:event_txtDireccionActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
JOptionPane.showMessageDialog(
            this, 
            "chao chao ><", 
            "Despedida", 
            JOptionPane.INFORMATION_MESSAGE
    );
        System.exit(0);

    }//GEN-LAST:event_btnSalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz_Bienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz_Bienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz_Bienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz_Bienvenida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz_Bienvenida().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardarCliente;
    private javax.swing.JButton btnRealizarPedido;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNombreCliente;
    // End of variables declaration//GEN-END:variables
}
