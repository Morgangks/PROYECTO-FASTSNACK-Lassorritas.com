package DAO;

import Config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Optional;
import modelo.Clientes;
import modelo.utilidades.DAOException;

public class ClienteDAOImpl implements ClienteDAO {
    private static ClienteDAOImpl instance;
    private final Conexion conexion;

    public ClienteDAOImpl() throws DAOException {
        this.conexion = Conexion.getInstance();
    }
    
    // MÉTODO NUEVO PARA GUARDAR EN MYSQL:
    public boolean insertar(Clientes cliente) throws DAOException {
        String sql = "INSERT INTO clientes (nombre, telefono, direccion) VALUES (?, ?, ?)";
        
        try (Connection conn = conexion.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, cliente.getNombre());
            pstmt.setString(2, cliente.getTelefono());
            pstmt.setString(3, cliente.getDireccion());
            
            int filasAfectadas = pstmt.executeUpdate();
            System.out.println("¡Datos guardados con éxito en MySQL!");
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            throw new DAOException("Error al insertar el cliente", e);
        }
    }
    
    @Override
    public Optional<Clientes> findByName(String nombre) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean existByPhone(String telefono) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}