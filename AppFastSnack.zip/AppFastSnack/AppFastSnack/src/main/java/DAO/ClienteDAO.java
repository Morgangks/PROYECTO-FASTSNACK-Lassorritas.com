  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.util.Optional;
import modelo.Clientes;
import modelo.utilidades.DAOException;

/**
 *
 * @author fl1pc12
 */
public interface ClienteDAO {
    public Optional<Clientes> findByName(String nombre) throws DAOException;
     public boolean existByPhone(String telefono) throws DAOException;
}
