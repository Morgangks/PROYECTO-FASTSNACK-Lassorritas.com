package Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import modelo.utilidades.DAOException;

public class Conexion {
    private static Conexion instancia;
    private Connection conexion;
    // Se recomienda agregar parámetros de zona horaria y SSL para evitar advertencias
    private final String url = "jdbc:mysql://localhost:3306/FastSnackbd?useSSL=false&serverTimezone=UTC";
    private final String user = "root";
    private final String password = "";

    private Conexion() throws DAOException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(url, user, password);
            System.out.println("¡Conexion exitosa a la base de datos!");
        } catch (ClassNotFoundException e) {
            throw new DAOException("No se encontró el Driver de MySQL", e);
        } catch (SQLException e) {
            throw new DAOException("Error al conectar con la base de datos. Verifica si MySQL está encendido o el nombre de la BD.", e);
        }
    }

    public static synchronized Conexion getInstance() throws DAOException {
        if (instancia == null) {
            instancia = new Conexion();
        }
        return instancia;
    }

    public Connection getConnection() throws DAOException {
        try {
            if (conexion == null || conexion.isClosed()) {
                conexion = DriverManager.getConnection(url, user, password);
            }
            return conexion;
        } catch (SQLException error) {
            throw new DAOException("No se pudo restablecer la conexión", error);
        }
    }

    public void CloseConexion() throws SQLException {
        if (conexion != null && !conexion.isClosed()) {
            conexion.close();
        }
        instancia = null;
    }
}